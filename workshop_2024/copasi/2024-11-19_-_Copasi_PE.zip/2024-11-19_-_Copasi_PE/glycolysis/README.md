## Glycolysis example
This example uses BioModel #172 and gives an example of using multiple data files. 

* import the sbml model
* add the first experimental data set, 
* estimate the parameters for `(ATPase).k1`, the `Vmax` for the hexokinase and phosphofructokinase. 
* how good is the fit?
* now add the second data set 
* specify that the external glucose is different for each experiment. 
 