## Local Minima
This example shows a model, that has many local minima, and so a local algorithm is likely to not find the best result in many cases. 

* import the SBML model into COPASI
* add the experimental data file, map the `Y obs` column to the transient concentration of `Y`
* estimate the reaction parameters and initial concentrations.
* add a parameter estimation result plot
* enable `Randomize Start Values`
* try several algorithms and see the difference 